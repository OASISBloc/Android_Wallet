package io.oasisbloc.wallet.model;

import java.util.ArrayList;
import java.util.List;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

import io.oasisbloc.wallet.data.Account;
import io.oasisbloc.wallet.data.LockupHistory;
import io.oasisbloc.wallet.data.Token;
import io.oasisbloc.wallet.data.TokenResources;
import io.oasisbloc.wallet.data.Transaction;
import io.oasisbloc.wallet.data.TransactionHistory;
import io.oasisbloc.wallet.model.repository.remote.LockupHistoryRemoteResult;
import io.oasisbloc.wallet.model.repository.remote.RemoteException;
import io.oasisbloc.wallet.model.repository.remote.RemoteRepository;
import io.oasisbloc.wallet.model.repository.remote.RemoteResult;
import io.reactivex.Completable;
import io.reactivex.Single;
import io.reactivex.schedulers.Schedulers;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public final class WalletModel {

    //    private static String TAG = WalletModel.class.getSimpleName();
    private static Repository API = RemoteRepository.createApi(Repository.class);
    //    private static final SharedPreferences LOCAL = PreferenceRepository.create(TAG);
    private static final long INTERVAL_MILLISECONDS = 0;

    public static Single<Account> getAccount() {
        return Single.timer(INTERVAL_MILLISECONDS, TimeUnit.MILLISECONDS)
                .flatMap(t -> API.getAccount(AccountModel.getAccount()))
                .flatMap(r -> {
                    if (r.isResult()) {
                        return Single.just(r.getData());
                    } else {
                        throw new RemoteException(r);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io());
    }

    public static Single<Double> getBalance() {
        return Single.timer(INTERVAL_MILLISECONDS, TimeUnit.MILLISECONDS)
                .flatMap(t -> API.getCurrencyBalance(AccountModel.getAccount()))
                .flatMap(r -> {
                    if (r.isResult()) {
                        return Single.just(r.getData());
                    } else {
                        throw new RemoteException(r);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io());
    }

    public static Single<List<Token>> getTokenList() {
        return Single.timer(INTERVAL_MILLISECONDS, TimeUnit.MILLISECONDS)
                .flatMap(t -> API.getCurrencyBalance(AccountModel.getAccount()))
                .flatMap(r -> {
                    if (r.isResult()) {
                        List<Token> list = new ArrayList<>();
                        list.add(new Token("OSB", r.getData()));
                        return Single.just(list);
                    } else {
                        throw new RemoteException(r);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io());
    }

    public static Completable sendToken(String target, String amount, String memo, String privateKey, String password) {
        return Single.timer(INTERVAL_MILLISECONDS, TimeUnit.MILLISECONDS)
                .flatMap(t -> API.transfer(
                        AccountModel.getAccount(),
                        target,
                        amount,
                        memo,
                        privateKey,
                        "Y",
                        password)
                )
                .flatMapCompletable(r -> {
                    if (r.isResult()) {
                        AccountModel.setPassword(password);
                        AccountModel.setPrivateKey(privateKey);
                        return Completable.complete();
                    } else {
                        throw new RemoteException(r);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io());
    }

    public static Single<TransactionHistory> getTransactionHistory() {
        TransactionHistory history = new TransactionHistory();
        String account = AccountModel.getAccount();
        int timezone = getTimezone();
        return Single.timer(INTERVAL_MILLISECONDS, TimeUnit.MILLISECONDS)
                .flatMap(t -> API.getCurrencyBalance(account))
                .flatMap(result -> {
                    if (result.isResult()) {
                        history.setTotalBalance(result.getData());
                        return API.getActions(account, timezone);
                    } else {
                        throw new RemoteException(result);
                    }
                })
                .flatMap(result -> {
                    if (result.isResult()) {
                        for (List<String> raw : result.getData()) {
                            history.add(Transaction.parse(raw));
                        }
                        return Single.just(history);
                    } else {
                        throw new RemoteException(result);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io());
    }

    public static Single<LockupHistory> getLockupHistory() {
        String account = AccountModel.getAccount();
        int timezone = getTimezone();
        return Single.timer(INTERVAL_MILLISECONDS, TimeUnit.MILLISECONDS)
                .flatMap(t -> API.getLockupTransactions(account, timezone))
                .flatMap(r -> {
                    if (r.isResult()) {
                        LockupHistory history = new LockupHistory();
                        history.setTotalBalance(r.getTotalBalance());
                        history.addAll(r.getData());
                        return Single.just(history);
                    } else {
                        throw new RemoteException(r);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io());
    }

    public static Single<TokenResources> getResources() {
        String account = AccountModel.getAccount();
        TokenResources resources = new TokenResources();
        return Single.timer(INTERVAL_MILLISECONDS, TimeUnit.MILLISECONDS)
                .flatMap(r -> API.getCurrencyBalance(account))
                .flatMap(r -> {
                    if (r.isResult()) {
                        resources.setSymbol("OSB");
                        resources.setBalance(r.getData());
                        return API.getAccount(account);
                    } else {
                        throw new RemoteException(r);
                    }
                })
                .flatMap(r -> {
                    if (r.isResult()) {
                        resources.setCpuTotal(r.getData().getCpuLimit().getMax());
                        resources.setCpuUsed(r.getData().getCpuLimit().getUsed());
                        resources.setCpuAvailable(r.getData().getCpuLimit().getAvailable());
                        resources.setCpuStake(r.getData().getCpuWeight() / 10000);
                        resources.setCpuRefunding(0);

                        resources.setNetTotal(r.getData().getNetLimit().getMax());
                        resources.setNetUsed(r.getData().getNetLimit().getUsed());
                        resources.setNetAvailable(r.getData().getNetLimit().getAvailable());
                        resources.setNetStake(r.getData().getNetWeight() / 10000);
                        resources.setNetRefunding(0);

                        resources.setRamTotal(r.getData().getRamLimit().getMax());
                        resources.setRamUsed(r.getData().getRamLimit().getUsed());
                        resources.setRamAvailable(resources.getRamTotal() - resources.getRamUsed());
                        resources.setRamStake(r.getData().getRamStake());
                        return Single.just(resources);
                    } else {
                        throw new RemoteException(r);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io());
    }

    private static int getTimezone() {
        return (int) TimeUnit.HOURS.convert(
                TimeZone.getDefault().getRawOffset(),
                TimeUnit.MILLISECONDS);
    }

    private interface Repository {

        @POST("api/getAccount")
        @FormUrlEncoded
        Single<RemoteResult<Account>> getAccount(
                @Field("account") String account);

        @POST("api/getCurrencyBalance")
        @FormUrlEncoded
        Single<RemoteResult<Double>> getCurrencyBalance(
                @Field("account") String account);

        @POST("api/getActions")
        @FormUrlEncoded
        Single<RemoteResult<List<List<String>>>> getActions(
                @Field("account") String account,
                @Field("timezoneoffset") int timezoneOffset);

        @POST("api/getLockupTransactions")
        @FormUrlEncoded
        Single<LockupHistoryRemoteResult> getLockupTransactions(
                @Field("account") String account,
                @Field("timezoneoffset") int timezoneOffset);

        @POST("api/transfer")
        @FormUrlEncoded
        Single<RemoteResult> transfer(
                @Field("account") String account,
                @Field("sendTo") String target,
                @Field("amount") String amount,
                @Field("memo") String memo,
                @Field("prvkey") String privateKey,
                @Field("chkPwdYn") String check,
                @Field("password") String password);
    }
}