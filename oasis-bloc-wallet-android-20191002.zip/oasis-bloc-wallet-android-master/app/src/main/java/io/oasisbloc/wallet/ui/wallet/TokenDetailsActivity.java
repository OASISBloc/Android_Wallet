package io.oasisbloc.wallet.ui.wallet;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentPagerAdapter;

import com.google.android.material.tabs.TabLayout;

import io.oasisbloc.wallet.R;
import io.oasisbloc.wallet.base.BaseActivity;
import io.oasisbloc.wallet.base.BaseFragment;
import io.oasisbloc.wallet.base.DecimalUtils;
import io.oasisbloc.wallet.data.LockupHistory;
import io.oasisbloc.wallet.data.TransactionHistory;
import io.oasisbloc.wallet.databinding.ActivityTokenDetailsBinding;
import io.oasisbloc.wallet.ui.history.LockupHistoryFragment;
import io.oasisbloc.wallet.ui.history.TransactionListFragment;
import io.oasisbloc.wallet.ui.history.viewmodel.LockupHistoryViewModel;
import io.oasisbloc.wallet.ui.history.viewmodel.TransactionHistoryViewModel;

public class TokenDetailsActivity extends BaseActivity {

    private static final String KEY_SYMBOL = "SYMBOL";

    private ActivityTokenDetailsBinding mBinding;

    public static void start(Context context, String symbol) {
        Intent starter = new Intent(context, TokenDetailsActivity.class);
        starter.putExtra(KEY_SYMBOL, symbol);
        context.startActivity(starter);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        String symbol = getIntent().getStringExtra(KEY_SYMBOL);
        int logo = R.drawable._temp_obs_ic_1;

        mBinding = DataBindingUtil.setContentView(this, R.layout.activity_token_details);
        mBinding.title.setText(symbol);
        mBinding.logo.setImageResource(logo);
        mBinding.send.setOnClickListener(v -> TokenSendActivity.start(this, symbol));
        mBinding.viewPager.setAdapter(new MyViewPagerAdapter());
        mBinding.tabLayout.setupWithViewPager(mBinding.viewPager);

        setSupportActionBar(mBinding.toolbarView);
        actionBarBackButtonEnable();
        setTransactionHistory(symbol, null);
        setLockupHistory(symbol, null);

        TransactionHistoryViewModel transactionVM = TransactionHistoryViewModel.get(this);
        transactionVM.getHistoryResult().observe(
                this,
                result -> setTransactionHistory(symbol, result),
                error -> setTransactionHistory(symbol, null),
                null);

        LockupHistoryViewModel lockupVM = LockupHistoryViewModel.get(this);
        lockupVM.getHistoryResult().observe(
                this,
                result -> setLockupHistory(symbol, result),
                error -> setLockupHistory(symbol, null),
                null);
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(R.anim.slide_none, R.anim.slide_out_right);
    }

    private void setTransactionHistory(String symbol, TransactionHistory history) {
        if (history == null) {
            mBinding.balance.setText(DecimalUtils.to(0, symbol));
        } else {
            mBinding.balance.setText(DecimalUtils.to(history.getTotalBalance(), symbol));
        }
    }

    private void setLockupHistory(String symbol, LockupHistory history) {
        if (history == null || history.isEmpty()) {
            mBinding.lockupLayout.setVisibility(View.GONE);
            mBinding.viewPager.disableScroll(true);
            TabLayout.Tab lockupTab = mBinding.tabLayout.getTabAt(1);
            if (lockupTab != null) {
                ((ViewGroup) lockupTab.view).setVisibility(View.INVISIBLE);
            }
        } else {
            mBinding.lockupLayout.setVisibility(View.VISIBLE);
            mBinding.lockup.setText(DecimalUtils.to(history.getTotalBalance(), symbol));
            mBinding.viewPager.disableScroll(false);
            TabLayout.Tab lockupTab = mBinding.tabLayout.getTabAt(1);
            if (lockupTab != null) {
                ((ViewGroup) lockupTab.view).setVisibility(View.VISIBLE);
            }
        }
    }

    private class MyViewPagerAdapter extends FragmentPagerAdapter {

        private BaseFragment[] mFragments = new BaseFragment[]{
                TransactionListFragment.newInstance(),
                LockupHistoryFragment.newInstance()
        };

        private MyViewPagerAdapter() {
            super(getSupportFragmentManager(), BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
        }

        @NonNull
        @Override
        public Fragment getItem(int position) {
            return mFragments[position];
        }

        @Override
        public int getCount() {
            return mFragments.length;
        }

        @Nullable
        @Override
        public CharSequence getPageTitle(int position) {
            if (position == 0) return getString(R.string.wallet_tab_transactions);
            else if (position == 1) return getString(R.string.wallet_tab_lockup);
            else return "";
        }
    }
}
