package io.oasisbloc.wallet.base.action;

public interface Action1<T> {
    void onAction(T data);
}
