package io.oasisbloc.wallet.ui.account;

public enum AccountCreateStep {
    ACCOUNT, PASSWORD, KEY_PAIR, EMAIL, DONE
}
