package io.oasisbloc.wallet.model;

import android.content.SharedPreferences;

import io.oasisbloc.wallet.App;
import io.oasisbloc.wallet.model.repository.PreferenceRepository;

public class DeviceModel {

    private static String TAG = DeviceModel.class.getSimpleName();
    private static final SharedPreferences LOCAL = PreferenceRepository.create(TAG + "1");

    private static final int APP_LOCK_ERROR_MAX_COUNT = App.isProduction() ? 10 : 3;
    private static final long APP_LOCK_ERROR_EXPIRED_MILLIS = App.isProduction() ? (5 * 60 * 1000) : (30 * 1000);
    private static final String KEY_APP_LOCK_CODE = "APP_LOCK_CODE";
    private static final String KEY_APP_LOCK_FIRST = "APP_LOCK_FIRST";
    private static final String KEY_APP_LOCK_ENABLED = "APP_LOCK_ENABLED";
    private static final String KEY_APP_LOCK_ERROR_COUNT = "APP_LOCK_ERROR_COUNT";
    private static final String KEY_APP_LOCK_BLOCK_TIME = "KEY_APP_LOCK_BLOCK_TIME";

    static void clear() {
        LOCAL.edit().clear().commit();
    }


    /*
        App lock
     */

    public static boolean isAppLockFirstLaunch() {
        return LOCAL.getBoolean(KEY_APP_LOCK_FIRST, true);
    }

    public static void setAppLockFirstLaunch(boolean first) {
        LOCAL.edit().putBoolean(KEY_APP_LOCK_FIRST, first).apply();
    }


    public static boolean isAppLockEnabled() {
        return LOCAL.getBoolean(KEY_APP_LOCK_ENABLED, false);
    }

    public static void setAppLockEnable(boolean enable) {
        LOCAL.edit().putBoolean(KEY_APP_LOCK_ENABLED, enable).apply();
    }

    public static void addAppLockErrorCount() {
        int count = getAppLockErrorNowCount() + 1;
        LOCAL.edit().putInt(KEY_APP_LOCK_ERROR_COUNT, count).apply();
    }

    public static int getAppLockErrorNowCount() {
        return LOCAL.getInt(KEY_APP_LOCK_ERROR_COUNT, 0);
    }

    public static void clearAppLockErrorCount() {
        LOCAL.edit().putInt(KEY_APP_LOCK_ERROR_COUNT, 0).apply();
    }

    public static int getAppLockErrorMaxCount() {
        return APP_LOCK_ERROR_MAX_COUNT;
    }

    public static boolean isAppLockBlocking() {
        return getAppLockErrorNowCount() >= getAppLockErrorMaxCount();
    }

    public static void updateAppLockBlockTime() {
        long time = System.currentTimeMillis() + APP_LOCK_ERROR_EXPIRED_MILLIS;
        LOCAL.edit().putLong(KEY_APP_LOCK_BLOCK_TIME, time).apply();
    }

    public static long getAppLockBlockRemindTimeSecond() {
        long time = LOCAL.getLong(KEY_APP_LOCK_BLOCK_TIME, 0) - System.currentTimeMillis();
        return time / 1000;
    }

    public static boolean isAppLockBlockRemindTimeExpired() {
        return getAppLockBlockRemindTimeSecond() <= 0;
    }

    public static String getAppLockCode() {
        return LOCAL.getString(KEY_APP_LOCK_CODE, "");
    }

    public static void setAppLockCode(String code) {
        LOCAL.edit().putString(KEY_APP_LOCK_CODE, code).apply();
    }


}
