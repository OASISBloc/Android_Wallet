package io.oasisbloc.wallet.ui.wallet;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;

import java.util.List;

import io.oasisbloc.wallet.R;
import io.oasisbloc.wallet.base.BaseFragment;
import io.oasisbloc.wallet.base.DecimalUtils;
import io.oasisbloc.wallet.base.ViewUtils;
import io.oasisbloc.wallet.data.Token;
import io.oasisbloc.wallet.databinding.FragmentWalletListBinding;
import io.oasisbloc.wallet.ui.resource.ResourcesActivity;
import io.oasisbloc.wallet.viewmodel.WalletListViewModel;

public class WalletListFragment extends BaseFragment {

    private FragmentWalletListBinding mBinding;
    private WalletListViewModel mViewModel;

    public static WalletListFragment newInstance() {
        Bundle args = new Bundle();
        WalletListFragment fragment = new WalletListFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        mBinding = DataBindingUtil.inflate(
                inflater,
                R.layout.fragment_wallet_list,
                container,
                false);
        return mBinding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        mBinding.summary.copy.setOnClickListener(v -> onCopyClicked());
        mBinding.limit.root.setOnClickListener(v -> onResourceClicked());
        mBinding.tokenAdd.setOnClickListener(v -> onTokenAddClicked());
        mBinding.tokenAdd.setVisibility(View.GONE);
        mBinding.token.root.setOnClickListener(v -> onTokenItemClicked());
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        mViewModel = WalletListViewModel.get(requireActivity(), getLifecycle());

        mViewModel.getAccount().observe(this, mBinding.summary.account::setText);
        mViewModel.getBalance().observe(this, mBinding.summary.balance::setText);
        mViewModel.getSymbol().observe(this, mBinding.summary.symbol::setText);

        mViewModel.getCpuPercent().observe(this, this::observeCpuPercent);
        mViewModel.getNetPercent().observe(this, this::observeNetPercent);
        mViewModel.getRamPercent().observe(this, this::observeRamPercent);

        mViewModel.getTokens().observe(this, this::observeTokens);
    }

    private void observeCpuPercent(double percent) {
        mBinding.limit.cpuPercent.setText(DecimalUtils.toPercent(percent));
        mBinding.limit.cpuGraph.setMax(Integer.MAX_VALUE);
        mBinding.limit.cpuGraph.setProgress((int) (percent * Integer.MAX_VALUE));
    }

    private void observeNetPercent(double percent) {
        mBinding.limit.netPercent.setText(DecimalUtils.toPercent(percent));
        mBinding.limit.netGraph.setMax(Integer.MAX_VALUE);
        mBinding.limit.netGraph.setProgress((int) (percent * Integer.MAX_VALUE));
    }

    private void observeRamPercent(double percent) {
        mBinding.limit.ramPercent.setText(DecimalUtils.toPercent(percent));
        mBinding.limit.ramGraph.setMax(Integer.MAX_VALUE);
        mBinding.limit.ramGraph.setProgress((int) (percent * Integer.MAX_VALUE));
    }

    private void observeTokens(List<Token> list) {
        if (!list.isEmpty()) {
            mBinding.token.name.setText(list.get(0).getSymbol());
            mBinding.token.balance.setText(DecimalUtils.to(list.get(0).getBalance()));
        }
    }

    private void onCopyClicked() {
        ViewUtils.copyToClipboard(mBinding.summary.account);
        getBaseActivity().showToast(R.string.msg_copied);
    }

    private void onResourceClicked() {
        ResourcesActivity.start(requireContext());
    }

    private void onTokenAddClicked() {

    }

    private void onTokenItemClicked() {
        TokenDetailsActivity.start(requireContext(), "OSB");
    }
}
