package io.oasisbloc.wallet.model;

import android.content.SharedPreferences;
import android.text.TextUtils;

import java.util.concurrent.TimeUnit;

import io.oasisbloc.wallet.data.KeyPair;
import io.oasisbloc.wallet.model.repository.PreferenceRepository;
import io.oasisbloc.wallet.model.repository.remote.RemoteException;
import io.oasisbloc.wallet.model.repository.remote.RemoteRepository;
import io.oasisbloc.wallet.model.repository.remote.RemoteResult;
import io.reactivex.Completable;
import io.reactivex.Single;
import io.reactivex.schedulers.Schedulers;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public class AccountModel {

    private static final String KEY_ACCOUNT = "KEY_ACCOUNT";
    private static final String KEY_PASSWORD = "KEY_PASSWORD";
    private static final String KEY_PUBLIC_KEY = "KEY_PUBLIC_KEY";
    private static final String KEY_PRIVATE_KEY = "KEY_PRIVATE_KEY";

    private static String TAG = AccountModel.class.getSimpleName();
    private static Repository API = RemoteRepository.createApi(Repository.class);
    private static final SharedPreferences LOCAL = PreferenceRepository.create(TAG + ".1");
    private static final long INTERVAL_MILLISECONDS = 1000;

    public static boolean hasAccount() {
        return !TextUtils.isEmpty(getAccount());
    }

    public static String getAccount() {
        return LOCAL.getString(KEY_ACCOUNT, "");
    }

    public static String getPassword() {
        return LOCAL.getString(KEY_PASSWORD, "");
    }

    public static String getPublicKey() {
        return LOCAL.getString(KEY_PUBLIC_KEY, "");
    }

    public static String getPrivateKey() {
        return LOCAL.getString(KEY_PRIVATE_KEY, "");
    }

    static void setPrivateKey(String key) {
        LOCAL.edit().putString(KEY_PRIVATE_KEY, key).apply();
    }

    static void setPassword(String password) {
        LOCAL.edit().putString(KEY_PASSWORD, password).apply();
    }


    public static Completable logout() {
        return Completable
                .create(emitter -> {
                    DeviceModel.clear();
                    boolean result = LOCAL.edit().clear().commit();
                    if (result) {
                        emitter.onComplete();
                    } else {
                        emitter.onError(new Exception());
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io());
    }

    public static Completable signInAccount(String account, String password) {
        return Single.timer(INTERVAL_MILLISECONDS, TimeUnit.MILLISECONDS)
                .flatMap(t -> API.login(account, password))
                .flatMapCompletable(r -> {
                    if (r.isResult()) {
                        LOCAL.edit()
                                .putString(KEY_ACCOUNT, account)
                                .putString(KEY_PASSWORD, password)
                                .putString(KEY_PUBLIC_KEY, r.getData())
                                .putString(KEY_PRIVATE_KEY, "")
                                .apply();
                        return Completable.complete();
                    } else {
                        throw new RemoteException(r);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io());
    }

    public static Completable importAccount(String account, String privateKey) {
        return Single.timer(INTERVAL_MILLISECONDS, TimeUnit.MILLISECONDS)
                .flatMap(t -> API.checkPrivateKey(account, privateKey))
                .flatMapCompletable(r -> {
                    if (r.isResult()) {
                        LOCAL.edit()
                                .putString(KEY_ACCOUNT, account)
                                .putString(KEY_PASSWORD, "")
                                .putString(KEY_PUBLIC_KEY, "")
                                .putString(KEY_PRIVATE_KEY, privateKey)
                                .apply();
                        return Completable.complete();
                    } else {
                        throw new RemoteException(r);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io());
    }

    public static Completable checkAccount(String account) {
        return Single.timer(INTERVAL_MILLISECONDS, TimeUnit.MILLISECONDS)
                .flatMap(t -> API.checkDuplAccount(account))
                .flatMapCompletable(r -> {
                    if (r.isResult()) {
                        if ("exist".equals(r.getMessage())) {
                            throw new Exception("Unavailable");
                        } else {
                            throw new RemoteException(r);
                        }
                    } else {
                        return Completable.complete();
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io());
    }

    public static Completable checkPassword(String password) {
        return Single.timer(INTERVAL_MILLISECONDS, TimeUnit.MILLISECONDS)
                .flatMap(t -> API.login(getAccount(), password))
                .flatMapCompletable(r -> {
                    if (r.isResult()) {
                        LOCAL.edit()
                                .putString(KEY_PASSWORD, password)
                                .putString(KEY_PUBLIC_KEY, r.getData())
                                .apply();
                        return Completable.complete();
                    } else {
                        throw new RemoteException(r);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io());
    }

    public static Single<KeyPair> createKeyPair() {
        return Single.timer(INTERVAL_MILLISECONDS, TimeUnit.MILLISECONDS)
                .flatMap(t -> API.generateKey())
                .flatMap(r -> {
                    if (r.isResult()) return Single.just(r.getData());
                    else throw new RemoteException(r);
                })
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io());
    }

    public static Completable createAccount(String account, String password,
                                            String publicKey, String email,
                                            boolean agree1, boolean agree2) {
        return Single.timer(INTERVAL_MILLISECONDS, TimeUnit.MILLISECONDS)
                .flatMap(t -> API.createAccount(
                        account, password,
                        publicKey, email,
                        bTos(agree1), bTos(agree2)))
                .flatMapCompletable(r -> {
                    if (r.isResult()) {
                        return Completable.complete();
                    } else {
                        throw new RemoteException(r);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io());
    }

    public static Completable sendPasswordResettingEmail(String account, String email) {
        return Single.timer(INTERVAL_MILLISECONDS, TimeUnit.MILLISECONDS)
                .flatMap(t -> API.forgotPasswordMail(account, email))
                .flatMapCompletable(r -> {
                    if (r.isResult()) {
                        return Completable.complete();
                    } else {
                        throw new RemoteException(r);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io());
    }

    private static String bTos(boolean bool) {
        return bool ? "Y" : "N";
    }

    private interface Repository {

        @POST("api/generateKey")
        Single<RemoteResult<KeyPair>> generateKey();

        @POST("api/checkDuplAccount")
        @FormUrlEncoded
        Single<RemoteResult> checkDuplAccount(
                @Field("account") String account);

        @POST("api/checkPrivateKey")
        @FormUrlEncoded
        Single<RemoteResult> checkPrivateKey(
                @Field("account") String account,
                @Field("prvKey") String privateKey);

        @POST("api/login")
        @FormUrlEncoded
        Single<RemoteResult<String>> login(
                @Field("memAccount") String account,
                @Field("memPwd") String password);

        @POST("api/createAccount")
        @FormUrlEncoded
        Single<RemoteResult<String>> createAccount(
                @Field("memAccount") String account,
                @Field("memPwd") String password,
                @Field("osbPublicKey") String publicKey,
                @Field("memEmail") String email,
                @Field("agree_1") String agree1,
                @Field("agree_2") String agree2);

        @POST("api/forgotPasswordMail")
        @FormUrlEncoded
        Single<RemoteResult> forgotPasswordMail(
                @Field("account") String account,
                @Field("email") String email);
    }
}
