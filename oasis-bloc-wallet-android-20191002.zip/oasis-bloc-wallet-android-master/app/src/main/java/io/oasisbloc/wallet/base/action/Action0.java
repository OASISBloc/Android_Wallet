package io.oasisbloc.wallet.base.action;

public interface Action0 {
    void onAction();
}
