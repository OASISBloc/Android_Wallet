package io.oasisbloc.wallet.ui.wallet.viewmodel;

public enum TokenSendStep {
    PRESET, PRIVATE_KEY, PASSWORD
}
