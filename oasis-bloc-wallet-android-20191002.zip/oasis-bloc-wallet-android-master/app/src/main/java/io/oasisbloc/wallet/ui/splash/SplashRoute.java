package io.oasisbloc.wallet.ui.splash;

public enum SplashRoute {
    MAIN, ACCOUNT, PIN_SETTING, PIN_CHECKING
}
