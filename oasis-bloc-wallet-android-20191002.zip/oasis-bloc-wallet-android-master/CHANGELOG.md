### 1.0.13
- store released.
- gitlab design issues fixed.

### 1.0.7
- gitlab issue(#3, #5, #19, #23) fixed.

### 1.0.6
- gitlab issue(#15, #16, #18, #19, #23, #37, #38, #47) fixed.

### 1.0.5
- gitlab issue(#10) fixed.

### 1.0.4
- gitlab issue(#10, #14, #20, #22, #23, #24, #27) fixed.

### 1.0.3
- lockup history bug fixed.

### 1.0.2
- app lock screen bug fixed.

### 1.0.1
- display development server information in splash screen.

### 1.0.0
- store released.
